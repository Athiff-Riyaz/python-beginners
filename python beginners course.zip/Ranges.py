numbers=list(range(10))
print(numbers)
#multiple arguments
number=list(range(3,8))
print(number)
#3rd argument
no=list(range(20,5,-2))
print(no)
#for loops
for i in range(5):
    print("hello!")
