age=42
print("his age is "+str(age))


name=input()
age=input()
print(name+" is "+age)



x=2
print(x)

x+=3
print(x)

z="pigeon"
print(z)
t+="eggs"
print(t)
