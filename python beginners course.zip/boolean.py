my_boolean=True
print(my_boolean)
True

print(2==3)
False

print("hello" == "hello")
True 

x=7
print(x!=8)
print(x>5)
print(x<2)
print(x>=7)
print(x<=7)