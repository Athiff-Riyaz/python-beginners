i=0
while True:
    print(i)
    i=i+1
    if i>=5:
        print("breaking")
        break
print("finished")
#continue
i=1
while i<=5:
    print(i)
    i+=1
    if i==3:
        print("skipping 3")
        continue

    