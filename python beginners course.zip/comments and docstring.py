def shout(word):
    """
    print a word with an
    exclamation mark following it.
    """
    print(word+"!")

shout("athiff")