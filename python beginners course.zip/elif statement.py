num=3
if num==1:
    print("one")
elif num==2:
    print("two")
elif num==3:
    print("three")
else:
    print("something else")

#Boolean logic
#and
print(1==1 and 2==2)
True
print(1==1 and 2==3)
False
print(1!=1 and 2==2)
False
print(2<1 and 3>6)
False
#or
print(1==1 or 2==2)
True
print(1==1 or 2==3)
True
print(1!=1 or 2==2)
True
print(2<1 or 3>6)
False
#not
print(not 1==1)
False
print(not 1>7)
True