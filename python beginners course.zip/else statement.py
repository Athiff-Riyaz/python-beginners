x=4
if x==5:
    print("yes")
else:
    print("no")

num=3
if num==1:
    print("one")
else:
    if num==2:
        print("two")
    else:
        if num==3:
            print("three")
        else:
            print("some thing else")