#function learned already
#print("hello")
#range(2,20)
#str(12)
#range(10,20,3)
nums=[1,2,3,4,5]
nums.append(6)
print(len(nums))

words=["python","fun"]
index=1
words.insert(index, "is")
print(words)

letters=['p','q','r','s','t','u']
print(letters.index('r'))
print(letters.index('p'))
print(letters.index('s'))
print(min(letters))
print(max(letters))
print(letters.count('u'))
print(letters.remove('r'))
print(letters.reverse())