print("hello world!")
print("hello")
print("nice to meet you ")