x=42
if x>5:
    print("x is greater than 5")

num=12
if num>5:
    print("bigger than 5")
    if num<=47:
        print("between 5 and 47")
