words=["hello","world","pizza","chicken"]
for word in words:
    print(word + "!")

str="testing for loops"
count=0
for x in str:
    if(x=='t'):
        count+=1

print(count)