str ="hello world!"
print(str[6])

#list operations
nums=[1,2,3]
print(nums+[4,5,6])
print(nums*3)

#question 
x=[2,4]
x+=[6,8]
print(x[2]//x[0])

#IN operation in list
word=["athiff","sahlan","furqan","faizal aathif"]
print("athiff" in word)
print("sahlan" in word)
print("faizal aathif" in word)
print("furqan" in word)
print("mohamed" in word)

#quiz
number=[10,9,8,7,6,5]
number[0]=number[1]-5
if 4 in number:
    print(number[3])
else:
    print(number[4])

#see how the below code works
no=[1,2,3]
print(not 4 in no)
print(4 not in no )
print(not 3 in no)
print(3 not in no)


