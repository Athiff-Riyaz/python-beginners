word=["hello","world","!"]
print(word[0])
print(word[1])
print(word[2])


m=[
    [1,2,3],
    [4,5,6]
]

print(m[1][2])