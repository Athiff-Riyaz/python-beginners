def my_func():
    print("athiff")
    print("athiff")
    print("athiff")

my_func()

def hello():
    print("hello world")

hello()
hello()
hello()
#arguments
def print_with_exclamation(word):
    print(word+"!")

print_with_exclamation("wow")
print_with_exclamation("hello")
print_with_exclamation("nice")
print_with_exclamation("python")

def print_sum_twice(x,y):
    print(x+y)
    print(x+y)
print_sum_twice(5, 8)