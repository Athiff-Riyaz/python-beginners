def max(x,y):
    if x >=y:
        return x
    else:
        return y

print(max(4, 7))
z=max(8,5)
print(z)

def addnumbers(a,b):
    total=a+b
    return total
    print("this won't be printed")

print(addnumbers(4, 5))