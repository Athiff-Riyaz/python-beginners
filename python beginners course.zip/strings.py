print("python is fun!")
print("always look on the bright side of life")
print('athiff\'s brother: he\'s not an angel. he\'s a very naughty boy!')
#newlines
print('one \ntwo \nthree')
#multi new lines
print("""this
 is a
  multiline
  text""")
  #concantenation
print("my food"+'eggs')
#string operations
print("athiff"*3)
print(4*'2')
print("42"+'5')