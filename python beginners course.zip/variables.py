user="athiff"
x=7
print(x)
print(x+3)
print(x)
print(user)
#WORKING WITH VARIABLES
x=123.456
print(x)
x="this is a string"
print(x+"!")