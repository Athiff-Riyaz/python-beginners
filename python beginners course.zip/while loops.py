i=1
while i<=5:
    print(i)
    i=i+1
print("finished!")

#multiple while loops
x=1
while x<10:
    if x%2 ==0:
        print(str(x) + " is even")
    else:
        print(str(x) + " is odd")

    x+=1